import React from 'react'

export default function ShopList() {
  return (
    <div className='container'>
      <h2>List of products in your list</h2>
      <div className='row'>
        
      </div>
    </div>
  )
}
