import React from 'react'

export default function ShopForm() {
  return (
    <div className='container mt-4'>
      <div className='col-md-6'>
        <h2>Add new product form:</h2>
        <label>Product name:</label>
        <input type="text" className='form-control' />
        <label>Product amount:</label>
        <input defaultValue={1} type="number" className='form-control' />
        <button className='mt-3'>Add product</button>
        <button className='mt-3'>Reset products list</button>
      </div>
    </div>
  )
}
