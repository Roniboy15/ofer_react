import React from 'react'
import ShopForm from './shopForm'

export default function ShopPage() {
  return (
    <React.Fragment>
      <ShopForm />
    </React.Fragment>
  )
}
