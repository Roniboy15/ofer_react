import React from 'react'

export default function ShopItem() {
  return (
    <div>ShopItem</div>
  )
}
